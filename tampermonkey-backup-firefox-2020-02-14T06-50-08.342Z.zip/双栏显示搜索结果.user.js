// ==UserScript==
// @name        双栏显示搜索结果
// @namespace   none
// @description 双栏显示baidu, sogou, so, google, bing的搜索结果
// @version     1.9.8
// @include     *://www.baidu.com/*
// @include     *://www.sogou.com/*
// @include     *://www.so.com/*
// @include     *://www.google.*/*
// @include     *://*.bing.com/*
// @grant       none
// @run-at      document-start
// ==/UserScript==

(function () {
    'use strict';
    var domURL = document.URL;
    var element = document.createElement('style');
    if (domURL.indexOf('baidu.com') !== - 1) {
        element.innerHTML = '#content_right{display:none}.container_l{width:99vw !important}#content_left{width:90vw !important;display: flex;flex-wrap: wrap}.c-container{width:47%;margin-right:25px;}#rs_top_new{width:100% !important}';
    }
    if (domURL.indexOf('sogou.com') !== - 1) {
        element.innerHTML = '#right{display:none}#main,.results{min-width:90vw !important;max-width:90vw !important;padding-right:0 !important;display: flex;flex-wrap: wrap}.results>div{width:47% !important;margin-right:25px;}.bing-snb{width:100%}';
    }
    if (domURL.indexOf('so.com') !== - 1) {
        element.innerHTML = '#side{display:none}#main,.result{width:90vw !important}.result{display: flex;flex-wrap: wrap}.res-list{width:47%;margin-right:25px;}'
    }
    if (domURL.indexOf('google') !== - 1) {
        element.innerHTML = '#rhscol,.rhscol{display:none !important;}#cnt #center_col{width: 90vw !important;}#TEPD0b{float: none !important; margin-bottom: 0 !important}.srg,.bkWMgd{display: flex;flex-wrap: wrap}.g,g-section-with-header,.xERobd{width: 47% !important;}.mR2gOd{width:95%}.COEoid{margin: -4px 0 !important;}.k2Oeod.eSq3C{right:18px !important;}.g>div,.g>g-section-with-header{width:95%;}.P1usbc{display:none !important}#tw-container,#tw-container ~ .di8g3{width:90%}#brs .med{width:200px}#cnt #foot{width:1px !important}.vk_c{border: 0px solid #dfe1e5 !important;}'
    }
    if (domURL.indexOf('bing.com') !== - 1) {
        element.innerHTML = '#b_context{display:none}#b_content{padding: 41px 100px 20px;}#b_results{width:100%;display: flex;flex-wrap: wrap}#b_results>li{width:47%;}.b_pag,.b_ans{width:100% !important}#b_results>.b_algo{padding: 20px}#b_results>li:first-child{padding-top:20px}#b_results>.b_pag{padding: 20px 0}'
    }
    document.documentElement.appendChild(element);
}) ();
